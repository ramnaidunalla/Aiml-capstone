# Modeling Results

## Class balance
survived
not_survived    0.617548
survived        0.382452

## Split
Stratified 80/20 train/test split with random_state=42. Stratification preserves the observed survived/not-survived class proportions in both splits.

## Classification
              model  accuracy  precision   recall       f1      auc
Logistic Regression  0.808989   0.783333 0.691176 0.734375 0.860963
      Decision Tree  0.764045   0.760000 0.558824 0.644068 0.837366
      Random Forest  0.808989   0.765625 0.720588 0.742424 0.819586

## Imbalance comparison
             strategy  precision   recall       f1
             baseline   0.765625 0.720588 0.742424
class_weight_balanced   0.765625 0.720588 0.742424
     SMOTE_train_only   0.761194 0.750000 0.755556

The three variants were evaluated on the identical test split. SMOTE is inside an imbalanced-learn pipeline, so oversampling occurs only after the training data enter the pipeline. The highest observed F1 is the `SMOTE_train_only` variant (0.756); it combines the highest observed recall (0.750) with precision of 0.761, so the held-out results favor that trade-off among the three tested variants.

## Random Forest tuning
Best parameters: `{'model__max_depth': 5, 'model__max_features': 'sqrt', 'model__n_estimators': 200}`. Best cross-validation F1: `0.7408`. OOB score of the refit best estimator: `0.8214`.

## Regression
MAE=18.3945, RMSE=41.3578, R2=0.3589, Adjusted R2=0.2679. The residual plot suggests heteroscedasticity because residual spread changes across fitted fare values.

## Deployment recommendation
The classifier selected for the saved end-to-end artifact is **Random Forest** because it has the highest observed F1 on this held-out test split (0.742). Accuracy=0.809, precision=0.766, recall=0.721, and AUC=0.820. This is a deployment recommendation based on the stated evaluation metrics, not a claim of universal superiority.
