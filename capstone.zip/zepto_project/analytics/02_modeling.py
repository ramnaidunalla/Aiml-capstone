from __future__ import annotations
from pathlib import Path
import json, joblib, numpy as np, pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix,accuracy_score,precision_score,recall_score,f1_score,roc_auc_score,roc_curve,mean_absolute_error,mean_squared_error,r2_score
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbPipeline
from common import adjusted_r2

ROOT=Path(__file__).resolve().parent; FIG=ROOT/'figures'; FIG.mkdir(exist_ok=True)
df=pd.read_csv(ROOT/'titanic.csv')
# titanic.csv is already cleaned by 01_eda.py; no sns.load_dataset call occurs here.
X=df[['pclass','sex','age','sibsp','parch','fare','embarked']]; y=df['survived']
class_balance=(y.value_counts().sort_index()/len(y)).rename(index={0:'not_survived',1:'survived'})
(ROOT/'class_balance.csv').write_text(class_balance.to_csv(header=['proportion']))
Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,stratify=y,random_state=42)
num=['pclass','age','sibsp','parch','fare']; cat=['sex','embarked']
pre=ColumnTransformer([('num',Pipeline([('imputer',SimpleImputer(strategy='median')),('scaler',StandardScaler())]),num),('cat',Pipeline([('imputer',SimpleImputer(strategy='most_frequent')),('onehot',OneHotEncoder(handle_unknown='ignore'))]),cat)])
models={'Logistic Regression':LogisticRegression(max_iter=2000),'Decision Tree':DecisionTreeClassifier(max_depth=5,random_state=42),'Random Forest':RandomForestClassifier(n_estimators=200,random_state=42)}
rows=[]
for name,est in models.items():
    pipe=Pipeline([('preprocess',pre),('model',est)]); pipe.fit(Xtr,ytr); pred=pipe.predict(Xte); proba=pipe.predict_proba(Xte)[:,1]
    rows.append(dict(model=name,accuracy=accuracy_score(yte,pred),precision=precision_score(yte,pred),recall=recall_score(yte,pred),f1=f1_score(yte,pred),auc=roc_auc_score(yte,proba)))
    cm=confusion_matrix(yte,pred); pd.DataFrame(cm,index=['actual_0','actual_1'],columns=['pred_0','pred_1']).to_csv(FIG/f'{name.lower().replace(" ","_")}_confusion_matrix.csv')
    fpr,tpr,_=roc_curve(yte,proba); plt.figure(); plt.plot(fpr,tpr,label=f'AUC={rows[-1]["auc"]:.3f}'); plt.plot([0,1],[0,1],linestyle='--'); plt.xlabel('FPR'); plt.ylabel('TPR'); plt.title(name+' ROC'); plt.legend(); plt.tight_layout(); plt.savefig(FIG/f'{name.lower().replace(" ","_")}_roc.png'); plt.close()
# Decision tree visualization
pipe_dt=Pipeline([('preprocess',pre),('model',models['Decision Tree'])]); pipe_dt.fit(Xtr,ytr)
features=pipe_dt.named_steps['preprocess'].get_feature_names_out(); plt.figure(figsize=(18,9)); plot_tree(pipe_dt.named_steps['model'],feature_names=features,class_names=['not_survived','survived'],filled=False,max_depth=3); plt.tight_layout(); plt.savefig(FIG/'decision_tree.png'); plt.close()

# Imbalance comparison using Random Forest, same split, SMOTE only in train pipeline.
def eval_pipe(p):
 p.fit(Xtr,ytr); pr=p.predict(Xte); return precision_score(yte,pr),recall_score(yte,pr),f1_score(yte,pr)
base=Pipeline([('preprocess',pre),('model',RandomForestClassifier(n_estimators=200,random_state=42))])
bal=Pipeline([('preprocess',pre),('model',RandomForestClassifier(n_estimators=200,class_weight='balanced',random_state=42))])
smote=ImbPipeline([('preprocess',pre),('smote',SMOTE(random_state=42)),('model',RandomForestClassifier(n_estimators=200,random_state=42))])
imb=pd.DataFrame([dict(strategy=s,precision=p,recall=r,f1=f) for s,p,r,f in [('baseline',*eval_pipe(base)),('class_weight_balanced',*eval_pipe(bal)),('SMOTE_train_only',*eval_pipe(smote))]])
imb.to_csv(ROOT/'imbalance_comparison.csv',index=False)
imb_best=imb.sort_values('f1',ascending=False).iloc[0]

# Grid search with OOB enabled
rf=RandomForestClassifier(oob_score=True,random_state=42,n_jobs=-1)
grid=GridSearchCV(Pipeline([('preprocess',pre),('model',rf)]),{'model__n_estimators':[100,200],'model__max_depth':[None,5,10],'model__max_features':['sqrt','log2']},cv=5,scoring='f1',n_jobs=-1)
grid.fit(Xtr,ytr); best=grid.best_estimator_; best_oob=best.named_steps['model'].oob_score_

# Regression side-task: predict fare from other available features, excluding fare.
regX=df.drop(columns=['fare','survived']); regy=df['fare']
rxtr,rxte,rytr,ryte=train_test_split(regX,regy,test_size=.2,random_state=42)
rnum=[c for c in ['pclass','age','sibsp','parch'] if c in regX]; rcat=[c for c in ['sex','embarked','class','who','adult_male','deck','embark_town','alone'] if c in regX]
rpre=ColumnTransformer([('num',Pipeline([('imp',SimpleImputer(strategy='median')),('scale',StandardScaler())]),rnum),('cat',Pipeline([('imp',SimpleImputer(strategy='most_frequent')),('oh',OneHotEncoder(handle_unknown='ignore'))]),rcat)])
rpipe=Pipeline([('preprocess',rpre),('model',LinearRegression())]); rpipe.fit(rxtr,rytr); rpred=rpipe.predict(rxte)
mae=mean_absolute_error(ryte,rpred); rmse=mean_squared_error(ryte,rpred)**.5; r2=r2_score(ryte,rpred); p=rpipe.named_steps['model'].coef_.shape[0]; ar2=adjusted_r2(r2,len(ryte),p)
res=ryte-rpred; plt.figure(); plt.scatter(rpred,res,alpha=.6); plt.axhline(0,linestyle='--'); plt.xlabel('Predicted fare'); plt.ylabel('Residual'); plt.title('Fare regression residuals'); plt.tight_layout(); plt.savefig(FIG/'fare_residuals.png'); plt.close()
hetero='The residual plot suggests heteroscedasticity because residual spread changes across fitted fare values.' if np.corrcoef(np.abs(res),rpred)[0,1]>.2 else 'The residual plot does not show strong evidence of heteroscedasticity; residual spread is broadly similar across fitted values.'

metrics=pd.DataFrame(rows); metrics.to_csv(ROOT/'classification_metrics.csv',index=False)
summary=metrics.copy(); summary['MAE']=np.nan; summary['RMSE']=np.nan; summary['R2']=np.nan; summary['Adjusted_R2']=np.nan
summary.loc[0,['MAE','RMSE','R2','Adjusted_R2']]=[mae,rmse,r2,ar2]
summary.to_csv(ROOT/'model_comparison.csv',index=False)
wide={'Logistic Regression':{},'Decision Tree':{},'Random Forest':{}}
for _,r in metrics.iterrows(): wide[r['model']]=r.to_dict()
wide_row={}
for m,vals in wide.items():
    for k,v in vals.items():
        if k!='model': wide_row[f'{m}_{k}']=v
wide_row.update({'Regression_MAE':mae,'Regression_RMSE':rmse,'Regression_R2':r2,'Regression_Adjusted_R2':ar2})
wide_df=pd.DataFrame([wide_row])
wide_df.to_csv(ROOT/'final_comparison_wide.csv',index=False)
# Best complete pipeline by F1
best_name=metrics.sort_values('f1',ascending=False).iloc[0]['model']; best_pipe=Pipeline([('preprocess',pre),('model',models[best_name])]); best_pipe.fit(Xtr,ytr); joblib.dump(best_pipe,ROOT/'artifacts/best_classifier_pipeline.joblib')
# Reload validation on raw rows
reloaded=joblib.load(ROOT/'artifacts/best_classifier_pipeline.joblib'); _=reloaded.predict(Xte.head(5))
report=f'''# Modeling Results\n\n## Class balance\n{class_balance.to_string()}\n\n## Split\nStratified 80/20 train/test split with random_state=42. Stratification preserves the observed survived/not-survived class proportions in both splits.\n\n## Classification\n{metrics.to_string(index=False)}\n\n## Imbalance comparison\n{imb.to_string(index=False)}\n\nThe three variants were evaluated on the identical test split. SMOTE is inside an imbalanced-learn pipeline, so oversampling occurs only after the training data enter the pipeline. The highest observed F1 is the `{imb_best.strategy}` variant ({imb_best.f1:.3f}); it combines the highest observed recall ({imb_best.recall:.3f}) with precision of {imb_best.precision:.3f}, so the held-out results favor that trade-off among the three tested variants.\n\n## Random Forest tuning\nBest parameters: `{grid.best_params_}`. Best cross-validation F1: `{grid.best_score_:.4f}`. OOB score of the refit best estimator: `{best_oob:.4f}`.\n\n## Regression\nMAE={mae:.4f}, RMSE={rmse:.4f}, R2={r2:.4f}, Adjusted R2={ar2:.4f}. {hetero}\n\n## Deployment recommendation\nThe classifier selected for the saved end-to-end artifact is **{best_name}** because it has the highest observed F1 on this held-out test split ({metrics.set_index('model').loc[best_name,'f1']:.3f}). Accuracy={metrics.set_index('model').loc[best_name,'accuracy']:.3f}, precision={metrics.set_index('model').loc[best_name,'precision']:.3f}, recall={metrics.set_index('model').loc[best_name,'recall']:.3f}, and AUC={metrics.set_index('model').loc[best_name,'auc']:.3f}. This is a deployment recommendation based on the stated evaluation metrics, not a claim of universal superiority.\n'''
(ROOT/'modeling_results.md').write_text(report,encoding='utf-8'); print(report)
