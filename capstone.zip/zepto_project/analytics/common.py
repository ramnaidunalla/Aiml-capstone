from __future__ import annotations
import pandas as pd
import numpy as np
from pathlib import Path

ROOT=Path(__file__).resolve().parent
NUMERIC=['age','fare','sibsp','parch','pclass','survived']
CORR_COLS=['survived','pclass','age','sibsp','parch','fare']

def clean_titanic(df):
    x=df.copy()
    # Threshold rule: <5% drop rows; 5-30% impute; >30% drop column.
    # On the standard dataset: age is ~19.9% -> median impute; embarked and embark_town are <5% -> row drop; deck is >30% -> drop.
    if 'deck' in x: x=x.drop(columns=['deck'])
    if 'age' in x: x['age']=x['age'].fillna(x['age'].median())
    for c in ['embarked','embark_town']:
        if c in x: x=x.dropna(subset=[c])
    return x.reset_index(drop=True)

def outlier_count(s):
    q1,q3=s.quantile([.25,.75]); iqr=q3-q1
    return int(((s<q1-1.5*iqr)|(s>q3+1.5*iqr)).sum())

def adjusted_r2(r2,n,p):
    return 1-(1-r2)*(n-1)/(n-p-1)
