# Analytics Pipeline

Run `python 01_eda.py` once. It calls `sns.load_dataset('titanic')` exactly once, writes the raw offline fallback, applies the specified missingness thresholds, then overwrites `titanic.csv` with the cleaned DataFrame used by modeling. Run `python 02_modeling.py` next; it reads that same CSV and never calls the Seaborn loader.

The modeling pipeline uses a stratified split before preprocessing. Numeric columns are median-imputed and standardized; `sex` and `embarked` are most-frequent-imputed and one-hot encoded inside a `ColumnTransformer`, ensuring train-only fitting. SMOTE is confined to the training fold by an imbalanced-learn pipeline.

See `eda_results.md` and `modeling_results.md` for generated interpretations and metrics. Figures are supporting artifacts only; the Markdown remains the source of required written interpretation. The saved classifier is a complete preprocessing+estimator pipeline and is reload-tested on raw feature rows.
