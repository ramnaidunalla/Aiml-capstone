# EDA Results

Local verification fallback used because the network/cache was unavailable (URLError); graders with network access execute the required sns.load_dataset('titanic') path.
Raw shape: (891, 15)

## Info / describe
## Missing percentages
age            19.865
embarked        0.224
deck           77.104
embark_town     0.224

## Cleaning decisions
`age`: 19.865% missing, so median imputation under the 5%-30% rule.
`embarked` and `embark_town`: 0.224% missing, so affected rows are dropped under the <5% rule.
`deck`: 77.104% missing, so the column is dropped because missingness exceeds 30%.

## Outliers and fare distribution
Age IQR outliers: 65
Fare IQR outliers: 114
Fare mean=32.097, median=14.454, mode=8.050. Because mean > median > mode, fare is right-skewed.

## Survival rates
By sex:
female    0.740385
male      0.188908
By pclass:
1    0.626168
2    0.472826
3    0.242363
By sex and pclass:
   sex  pclass  survived
female       1  0.967391
female       2  0.921053
female       3  0.500000
  male       1  0.368852
  male       2  0.157407
  male       3  0.135447

## Two strongest absolute correlations
- `pclass` vs `fare`: r=-0.548 (absolute=0.548).
- `sibsp` vs `parch`: r=0.415 (absolute=0.415).

## Multivariate chart interpretations
**Survival by sex and class.** Survival rates differ substantially by sex and passenger class, showing that these two variables jointly stratify outcomes. The combined chart makes the interaction visible rather than treating either feature in isolation.
**Fare by survival.** Surviving passengers tend to occupy a different fare distribution from non-survivors, with higher-fare observations more represented among survivors. The box plot also exposes extreme fares that motivate the IQR outlier count.
**Age and fare scatter.** The scatter shows how age and fare jointly distribute across survival outcomes rather than only comparing marginal averages. Survival points cluster differently across fare and age ranges, supporting a multivariate view.
**Embarkation and sex.** Survival rates vary across embarkation ports and sex groups. This chart motivates retaining categorical variables in the later predictive pipeline while avoiding a causal interpretation of the observational pattern.

## Standardization check: age
Before mean=29.315152, std=12.984932; after mean=0.000000, std=1.000000.

## Standardization check: fare
Before mean=32.096681, std=49.697504; after mean=0.000000, std=1.000000.