# Zepto Data Engineering, Analytics & Support Assistant

This is a single repository containing all three required modules: `/data_pipeline`, `/analytics`, and `/support_assistant`. All interpretations live in Markdown files or generated Markdown reports inside the repository; charts are supporting artifacts only.

## Setup

This project uses **one consolidated `requirements.txt` at repository root**. Create a virtual environment and install it:

```bash
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
```

No paid service is required. The data pipeline uses a public scraping-practice site and a fixed project conversion rate. The analytics module uses Seaborn's built-in Titanic loader once and commits the resulting cleaned `titanic.csv` fallback. The support assistant uses local Sentence Transformers + ChromaDB and defaults to deterministic `MOCK_LLM=1`.

## Module 1 — Data Pipeline

```bash
cd data_pipeline
python pipeline.py
```

The script scrapes the first five all-products pages from Books to Scrape, cleans at least 60 books, converts `price_gbp` to `price_inr` using the required **1 GBP = 105.50 INR** fixed baseline, creates `books.db`, and executes six SQL queries. Query strings/outputs are under `data_pipeline/sql_outputs/`. The normalized schema is `categories(category_id)` → `books(category_id)`.

## Module 2 — Analytics

```bash
cd analytics
python 01_eda.py
python 02_modeling.py
```

`01_eda.py` performs the single `sns.load_dataset('titanic')` load, reports missingness and cleaning decisions, produces the required EDA figures and Markdown interpretation, and saves the cleaned `titanic.csv`. `02_modeling.py` reads that same CSV, performs the stratified split before train-only preprocessing, evaluates Logistic Regression/Decision Tree/Random Forest, compares imbalance strategies, tunes an OOB-enabled Random Forest, completes the fare regression, and saves the complete fitted classifier pipeline under `analytics/artifacts/`.

The saved artifact is an end-to-end scikit-learn Pipeline: raw input columns → imputation/encoding/scaling → classifier. It is reloaded and prediction-tested in the modeling script.

## Module 3 — Support Assistant

```bash
MOCK_LLM=1 uvicorn support_assistant.main:app --host 127.0.0.1 --port 7860
```

Then POST `{"query":"..."}` to `/ask`. The eight exact corpus documents live under `support_assistant/docs/`. `classify_intent`, `retrieve_and_answer`, and `direct_answer` form the LangGraph `StateGraph`; retrieval uses local `all-MiniLM-L6-v2` embeddings and a ChromaDB collection named `zepto_policy`. Mock generation is deterministic and requires no API key.

Optional real LLM mode is `MOCK_LLM=0` with a free Groq-tier account and `GROQ_API_KEY`; it is not needed for grading. The real path validates Pydantic JSON and retries invalid output up to two additional times.

### Docker

```bash
docker build -t zepto-support -f support_assistant/Dockerfile .
docker run --rm -p 7860:7860 zepto-support
```

## Design decisions

### Data pipeline
A page-based scrape was chosen because it is deterministic and requires no login. Numeric parsing failures use median imputation; rows missing identity/category fields are dropped. SQLite separates categories from books to satisfy normalization and preserve referential integrity.

### Analytics
The raw Titanic data is loaded once, immediately persisted as the offline fallback, cleaned according to the specified missingness thresholds, and then reused through the committed CSV. Modeling preprocessing is isolated inside a `ColumnTransformer` fitted only within the training split. SMOTE is placed after preprocessing inside an imbalanced-learn pipeline so test data are never oversampled.

### Support assistant
Each policy document is a single chunk because the supplied documents are short. Explicit embeddings are stored in ChromaDB so retrieval is transparent and local. LangGraph owns routing/orchestration, while Pydantic owns the final response contract. The mock branch is the default graded baseline and never calls an external LLM.

## Git workflow

The repository history is intentionally maintained with a feature branch containing at least two commits followed by a merge into `main`, satisfying the repository-wide workflow requirement.

## Verification notes

The data-pipeline outputs were executed locally and validated with `data_pipeline/validate_outputs.py`: 60 rows, 25 categories, fixed-rate INR conversion, SQLite row/category counts, and equality of the SQL-join/pandas-merge outputs all passed.

The analytics scripts were executed locally against the same classic Titanic data represented by the committed offline verification fallback because this execution environment could not resolve the external dataset URL. The generated EDA/model metrics, figures, and reloadable classifier artifact are committed. On a normal network-enabled machine, `01_eda.py` first executes the required `sns.load_dataset('titanic')` call and then uses its own saved CSV for the remainder of the module.

The support-assistant source is structurally validated and Python-compiles. Its runtime dependencies (`langgraph`, `chromadb`, and `sentence-transformers`) were not available in this execution environment and could not be installed because outbound package DNS was unavailable; installing the consolidated requirements on a network-enabled machine is the remaining runtime setup step for that module.
