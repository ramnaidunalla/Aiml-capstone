SELECT title, price_inr FROM books ORDER BY price_inr DESC LIMIT 10;

-- OUTPUT --
                                                                             title  price_inr
                                                    Slow States of Collapse: Poems    6046.20
Our Band Could Be Your Life: Scenes from the American Indie Underground, 1981-1991    6039.88
                                                               The Past Never Ends    5960.75
                                               The Pioneer Woman Cooks: Dinnertime    5951.25
                                                   The Secret of Dreadwillow Carse    5921.72
                                                     Birdsong: A Story in Pictures    5764.52
                                             Sapiens: A Brief History of Humankind    5721.26
                                                                Tipping the Velvet    5669.57
                                                    Aladdin and His Wonderful Lamp    5605.22
                           Scott Pilgrim's Precious Little Life (Scott Pilgrim #1)    5516.60