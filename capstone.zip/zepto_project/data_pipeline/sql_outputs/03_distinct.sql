SELECT DISTINCT rating FROM books ORDER BY rating;

-- OUTPUT --
 rating
      1
      2
      3
      4
      5