SELECT title, price_gbp FROM books WHERE price_gbp BETWEEN 10 AND 20 ORDER BY price_gbp;

-- OUTPUT --
                                                                                  title  price_gbp
                                                                            In Her Wake      12.84
                                         Starving Hearts (Triangular Trade Trilogy, #1)      13.99
                                                Untitled Collection: Sabbath Poems 2014      14.27
                                                                         Sophie's World      15.94
                                                             Tsubasa: WoRLD CHRoNiCLE 2      16.28
                                                                                 Thirst      17.27
                                                                            Set Me Free      17.46
                             The Four Agreements: A Practical Guide to Personal Freedom      17.66
The Coming Woman: A Novel Based on the Life of the Infamous Feminist, Victoria Woodhull      17.93
                                         Maude (1883-1993):She Grew Up with the country      18.02
                                                                         Unicorn Tracks      18.78
                                            The Torch Is Passed: A Harding Family Story      19.09
                                                                        This One Summer      19.49
                                                                   In a Dark, Dark Wood      19.63