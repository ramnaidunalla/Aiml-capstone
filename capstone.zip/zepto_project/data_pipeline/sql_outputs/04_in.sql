SELECT title, rating FROM books WHERE rating IN (4,5) ORDER BY rating DESC, title LIMIT 20;

-- OUTPUT --
                                                                                         title  rating
                            #HigherSelfie: Wake Up Your Life. Free Your Soul. Find Your Tribe.       5
                                                                                    Black Dust       5
                                                                    Chase Me (Paris Nights #2)       5
                                                                   Private Paris (Private #10)       5
                                                                     Rip it Up and Start Again       5
                                                         Sapiens: A Brief History of Humankind       5
                                       Scott Pilgrim's Precious Little Life (Scott Pilgrim #1)       5
                                                                                   Set Me Free       5
                                                                                Sophie's World       5
                                                                             The Elephant Tree       5
                                    The Four Agreements: A Practical Guide to Personal Freedom       5
                                                                                        Thirst       5
                                                                  We Love You, Charlie Freeman       5
                                         Worlds Elsewhere: Journeys Around Shakespeare's Globe       5
                                                                           Behind Closed Doors       4
                                                                         Shakespeare's Sonnets       4
                                                                                 Sharp Objects       4
The Boys in the Boat: Nine Americans and Their Epic Quest for Gold at the 1936 Berlin Olympics       4
                                            The Dirty Little Secrets of Getting Your Dream Job       4
                                                                           The Past Never Ends       4