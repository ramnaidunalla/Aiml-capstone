SELECT c.category_name, b.title, b.rating, b.price_gbp FROM books b JOIN categories c ON b.category_id=c.category_id ORDER BY b.rating DESC, c.category_name, b.title LIMIT 10;

-- OUTPUT --
category_name                                                              title  rating  price_gbp
      fiction                                        Private Paris (Private #10)       5      47.61
      fiction                                                             Thirst       5      17.27
      fiction                                       We Love You, Charlie Freeman       5      50.27
      history                              Sapiens: A Brief History of Humankind       5      54.23
        music                                          Rip it Up and Start Again       5      35.02
   nonfiction #HigherSelfie: Wake Up Your Life. Free Your Soul. Find Your Tribe.       5      23.11
   nonfiction              Worlds Elsewhere: Journeys Around Shakespeare's Globe       5      40.30
   philosophy                                                     Sophie's World       5      15.94
      romance                                                         Black Dust       5      34.53
      romance                                         Chase Me (Paris Nights #2)       5      25.27