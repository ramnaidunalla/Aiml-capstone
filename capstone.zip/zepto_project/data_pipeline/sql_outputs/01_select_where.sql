SELECT title, price_gbp FROM books WHERE rating >= 4 ORDER BY price_gbp DESC;

-- OUTPUT --
                                                                                                    title  price_gbp
                                                                                      The Past Never Ends      56.50
                                                                    Sapiens: A Brief History of Humankind      54.23
                                                  Scott Pilgrim's Precious Little Life (Scott Pilgrim #1)      52.29
                                                                                      Behind Closed Doors      52.22
                                                                             We Love You, Charlie Freeman      50.27
                                                                                            Sharp Objects      47.82
                                                                              Private Paris (Private #10)      47.61
                                                                                           Wall and Piece      44.18
Unseen City: The Majesty of Pigeons, the Discreet Charm of Snails & Other Wonders of the Urban Wilderness      44.18
                                                    Worlds Elsewhere: Journeys Around Shakespeare's Globe      40.30
                                                                                Rip it Up and Start Again      35.02
                                                                                               Black Dust      34.53
                                                       The Dirty Little Secrets of Getting Your Dream Job      33.34
                                                                               Chase Me (Paris Nights #2)      25.27
                                                                                        The Elephant Tree      23.82
                                       #HigherSelfie: Wake Up Your Life. Free Your Soul. Find Your Tribe.      23.11
           The Boys in the Boat: Nine Americans and Their Epic Quest for Gold at the 1936 Berlin Olympics      22.60
                                                                                    Shakespeare's Sonnets      20.66
                                                                                          This One Summer      19.49
                                               The Four Agreements: A Practical Guide to Personal Freedom      17.66
                                                                                              Set Me Free      17.46
                                                                                                   Thirst      17.27
                                                                                           Sophie's World      15.94
                                                                  Untitled Collection: Sabbath Poems 2014      14.27