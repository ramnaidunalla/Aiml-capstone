from pathlib import Path
import sqlite3, pandas as pd
ROOT=Path(__file__).resolve().parent
books=pd.read_csv(ROOT/'clean_books.csv')
assert len(books)>=60 and books.category.nunique()>=3
assert books.rating.between(1,5).all()
assert (books.price_inr.round(2)==(books.price_gbp*105.50).round(2)).all()
con=sqlite3.connect(ROOT/'books.db'); con.execute('PRAGMA foreign_keys=ON')
assert con.execute('SELECT COUNT(*) FROM books').fetchone()[0]>=60
assert con.execute('SELECT COUNT(*) FROM categories').fetchone()[0]>=3
assert pd.read_csv(ROOT/'sql_outputs/join_pd_read_sql.csv').equals(pd.read_csv(ROOT/'sql_outputs/join_pd_merge.csv'))
print('data_pipeline validation: PASS')
