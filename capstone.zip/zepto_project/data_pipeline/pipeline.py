from __future__ import annotations
import re, sqlite3
from pathlib import Path
import pandas as pd
import requests
from bs4 import BeautifulSoup

BASE_URL = "https://books.toscrape.com/"
RATE_GBP_TO_INR = 105.50
ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / "books.db"
OUTPUT_CSV = ROOT / "clean_books.csv"
SQL_OUTPUT = ROOT / "sql_outputs"

RATING_MAP = {"One":1,"Two":2,"Three":3,"Four":4,"Five":5}

def parse_page(url: str) -> list[dict]:
    r = requests.get(url, timeout=30); r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")
    rows=[]
    for card in soup.select("article.product_pod"):
        title = card.h3.a.get("title", "").strip()
        price = card.select_one(".price_color").get_text(strip=True)
        rating_text = next((c for c in card.get("class",[]) if c in RATING_MAP), None)
        if rating_text is None:
            rating_text = card.select_one(".star-rating").get("class", ["","Unknown"])[1]
        availability = card.select_one(".availability").get_text(" ", strip=True)
        category = ""
        detail = card.h3.a.get("href")
        if detail:
            detail_url = requests.compat.urljoin(url, detail)
            dr = requests.get(detail_url, timeout=30); dr.raise_for_status()
            ds = BeautifulSoup(dr.text, "html.parser")
            crumbs = [x.get_text(strip=True) for x in ds.select("ul.breadcrumb li")]
            if len(crumbs) >= 3: category = crumbs[-2]
        rows.append(dict(title=title, price=price, star_rating=rating_text,
                         availability=availability, category=category))
    return rows

def scrape_all_products(min_rows=60) -> pd.DataFrame:
    rows=[]
    for page in range(1, 6):
        url = BASE_URL if page == 1 else f"{BASE_URL}catalogue/page-{page}.html"
        # All-products pages are sufficient and reproducible.
        rows.extend(parse_page(url))
    df = pd.DataFrame(rows).drop_duplicates(subset=["title"]).reset_index(drop=True)
    if len(df) < min_rows: raise RuntimeError(f"Expected >= {min_rows} books, got {len(df)}")
    return df

def clean(df: pd.DataFrame) -> pd.DataFrame:
    out=df.copy()
    out["price_gbp"] = pd.to_numeric(out["price"].astype(str).str.replace(r"[^0-9.]", "", regex=True), errors="coerce")
    out["rating"] = out["star_rating"].map(RATING_MAP).astype("Float64")
    out["in_stock"] = out["availability"].str.contains("In stock", case=False, na=False)
    # Numeric parse failures use medians; categorical parse failures are dropped.
    for c in ["price_gbp", "rating"]:
        if out[c].isna().any(): out[c] = out[c].fillna(out[c].median())
    out = out.dropna(subset=["title","category"]).copy()
    out["rating"] = out["rating"].astype(int)
    out["price_inr"] = (out["price_gbp"] * RATE_GBP_TO_INR).round(2)
    return out[["title","price_gbp","price_inr","rating","in_stock","category","star_rating","availability"]]

def load_sqlite(df: pd.DataFrame):
    con=sqlite3.connect(DB_PATH); con.execute("PRAGMA foreign_keys=ON")
    cur=con.cursor()
    cur.executescript("""
    DROP TABLE IF EXISTS books; DROP TABLE IF EXISTS categories;
    CREATE TABLE categories(category_id INTEGER PRIMARY KEY, category_name TEXT UNIQUE NOT NULL);
    CREATE TABLE books(book_id INTEGER PRIMARY KEY, title TEXT NOT NULL, price_gbp REAL NOT NULL,
      price_inr REAL NOT NULL, rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
      in_stock INTEGER NOT NULL, category_id INTEGER NOT NULL REFERENCES categories(category_id));
    """)
    cats=sorted(df.category.unique())
    cur.executemany("INSERT INTO categories(category_name) VALUES (?)", [(x,) for x in cats])
    mapping={name:i+1 for i,name in enumerate(cats)}
    data=[]
    for _,r in df.iterrows():
        data.append((r.title,r.price_gbp,r.price_inr,r.rating,int(bool(r.in_stock)),mapping[r.category]))
    cur.executemany("INSERT INTO books(title,price_gbp,price_inr,rating,in_stock,category_id) VALUES (?,?,?,?,?,?)", data)
    con.commit(); return con

def run_queries(con):
    SQL_OUTPUT.mkdir(exist_ok=True)
    queries={
      "01_select_where":"SELECT title, price_gbp FROM books WHERE rating >= 4 ORDER BY price_gbp DESC;",
      "02_order_limit":"SELECT title, price_inr FROM books ORDER BY price_inr DESC LIMIT 10;",
      "03_distinct":"SELECT DISTINCT rating FROM books ORDER BY rating;",
      "04_in":"SELECT title, rating FROM books WHERE rating IN (4,5) ORDER BY rating DESC, title LIMIT 20;",
      "05_between":"SELECT title, price_gbp FROM books WHERE price_gbp BETWEEN 10 AND 20 ORDER BY price_gbp;",
      "06_join":"SELECT c.category_name, b.title, b.rating, b.price_gbp FROM books b JOIN categories c ON b.category_id=c.category_id ORDER BY b.rating DESC, c.category_name, b.title LIMIT 10;"
    }
    outputs={}
    for name,q in queries.items():
        d=pd.read_sql_query(q, con); outputs[name]=d
        (SQL_OUTPUT/f"{name}.sql").write_text(q+"\n\n-- OUTPUT --\n"+d.to_string(index=False), encoding="utf-8")
    # Two pd.read_sql results and equivalent in-memory merge.
    q1=queries["01_select_where"]; q2=queries["02_order_limit"]
    pd.read_sql(q1,con).to_csv(SQL_OUTPUT/"pd_read_sql_query1.csv",index=False)
    pd.read_sql(q2,con).to_csv(SQL_OUTPUT/"pd_read_sql_query2.csv",index=False)
    books=pd.read_sql("SELECT * FROM books",con); cats=pd.read_sql("SELECT * FROM categories",con)
    sql_join=pd.read_sql(queries["06_join"],con)
    merged=books.merge(cats,on="category_id",how="inner")[["category_name","title","rating","price_gbp"]].sort_values(["rating","category_name","title"],ascending=[False,True,True]).head(10).reset_index(drop=True)
    sql_join.to_csv(SQL_OUTPUT/"join_pd_read_sql.csv",index=False); merged.to_csv(SQL_OUTPUT/"join_pd_merge.csv",index=False)
    assert sql_join.reset_index(drop=True).equals(merged)
    return outputs

def main():
    try:
        raw=scrape_all_products()
        source="live Books to Scrape"
    except requests.RequestException as exc:
        seed=ROOT / "offline_seed.csv"
        if not seed.exists(): raise
        raw=pd.read_csv(seed)
        source=f"offline verification seed after live request failure: {exc.__class__.__name__}"
    clean_df=clean(raw); clean_df.to_csv(OUTPUT_CSV,index=False)
    con=load_sqlite(clean_df); run_queries(con); con.close()
    print(f"Loaded {len(raw)} unique books across {raw.category.nunique()} categories from {source}")
    print(f"Saved {OUTPUT_CSV} and {DB_PATH}")

if __name__ == "__main__": main()
