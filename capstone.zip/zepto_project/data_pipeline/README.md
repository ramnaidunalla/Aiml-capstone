# Data Pipeline

Run `python pipeline.py`. The script scrapes the first five all-products pages from Books to Scrape, yielding at least 60 books, cleans the fields, converts GBP to INR at the required fixed rate **1 GBP = 105.50 INR**, loads a normalized SQLite database, and writes six SQL query/output files.

Numeric parse failures are median-imputed; rows missing required title/category fields are dropped because those fields cannot be meaningfully reconstructed. `in_stock` is derived from the availability text. The schema uses `categories(category_id)` and `books(category_id)` as the required PK/FK relationship.

`sql_outputs/` contains query strings and printed outputs. The join is executed with SQL and reproduced from in-memory pandas frames with `merge`, and the outputs are asserted equivalent.
