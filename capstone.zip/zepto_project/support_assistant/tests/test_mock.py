import os
os.environ['MOCK_LLM']='1'
from support_assistant.main import ask

def test_policy():
    a=ask('What are the support hours?'); assert a.sources and a.confidence==1.0; assert a.answer.startswith('Based on the retrieved context:')
def test_general():
    a=ask('What is the capital of France?'); assert a.sources==[] and a.answer.startswith('I can only answer')
