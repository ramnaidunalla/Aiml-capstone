from __future__ import annotations
import os, re
from pathlib import Path
from typing import TypedDict, Literal
from pydantic import BaseModel, Field, ValidationError
from langgraph.graph import StateGraph, END
import chromadb
from sentence_transformers import SentenceTransformer

ROOT=Path(__file__).resolve().parent; DOCS=ROOT/'docs'; DB=ROOT/'chroma_db'; COLLECTION='zepto_policy'
KEYWORDS=['delivery','return','refund','membership','tracking','cancel','gift card','support hours']
MODEL_NAME='all-MiniLM-L6-v2'
_model=None; _collection=None

class Answer(BaseModel):
    answer: str
    sources: list[str]
    confidence: float=Field(ge=0,le=1)
class AskRequest(BaseModel): query: str
class State(TypedDict, total=False):
    query: str; intent: Literal['policy_question','general_question']; retrieved: list[dict]; response: Answer

PROMPT_TEMPLATE='''ROLE: You are a Zepto policy support assistant.\nCONTEXT: Use only the retrieved policy chunks supplied below.\nTASK: Answer the user's question using the provided context.\nFORMAT: Return a JSON object with answer, sources, and confidence.\nLENGTH: Keep the answer concise and directly relevant.\nNEGATIVE CONSTRAINT: Do not answer using information not present in the provided context; if the context does not support an answer, say so.\nFEW-SHOT EXAMPLE:\nUser: How long can I report a damaged grocery item?\nContext: Grocery and perishable items may be reported within 24 hours.\nAnswer: Damaged grocery items may be reported within 24 hours of delivery.\n'''

def get_model():
    global _model
    if _model is None: _model=SentenceTransformer(MODEL_NAME)
    return _model

def get_collection():
    global _collection
    if _collection is not None: return _collection
    client=chromadb.PersistentClient(path=str(DB))
    _collection=client.get_or_create_collection(COLLECTION, metadata={'hnsw:space':'cosine'})
    if _collection.count() < 8:
        docs=[]; ids=[]; metas=[]
        for p in sorted(DOCS.glob('doc_*.txt')):
            docs.append(p.read_text(encoding='utf-8')); ids.append(p.stem); metas.append({'document_id':p.stem})
        emb=get_model().encode(docs,normalize_embeddings=True).tolist()
        _collection.upsert(ids=ids,documents=docs,metadatas=metas,embeddings=emb)
    return _collection

def classify_intent(state: State):
    q=state['query'].lower(); intent='policy_question' if any(k in q for k in KEYWORDS) else 'general_question'
    return {'intent':intent}

def retrieve_and_answer(state: State):
    col=get_collection(); qemb=get_model().encode([state['query']],normalize_embeddings=True).tolist()[0]
    res=col.query(query_embeddings=[qemb],n_results=3,include=['documents','metadatas','distances'])
    retrieved=[{'id':i,'text':d,'distance':dist} for i,d,dist in zip(res['ids'][0],res['documents'][0],res['distances'][0])]
    top=retrieved[0]['text']; snippet=top[:200].strip()
    if os.getenv('MOCK_LLM','1') != '0':
        answer=f'Based on the retrieved context: {snippet}'
        return {'retrieved':retrieved,'response':Answer(answer=answer,sources=[x['id'] for x in retrieved],confidence=1.0)}
    return {'retrieved':retrieved,'response':real_llm_answer(state['query'],retrieved)}

def direct_answer(state: State):
    if os.getenv('MOCK_LLM','1') != '0':
        return {'response':Answer(answer='I can only answer questions about Zepto policies right now.',sources=[],confidence=1.0)}
    return {'response':real_llm_answer(state['query'],[])}

def real_llm_answer(query,retrieved):
    # Optional Groq extension. Raw JSON is validated and retried twice if invalid.
    from groq import Groq
    client=Groq(api_key=os.environ['GROQ_API_KEY']); context='\n'.join(x['text'] for x in retrieved)
    corrective=''
    for _ in range(3):
        prompt=PROMPT_TEMPLATE+'\nCONTEXT CHUNKS:\n'+context+'\nUSER QUERY:\n'+query+'\n'+corrective
        raw=client.chat.completions.create(model=os.getenv('GROQ_MODEL','llama-3.1-8b-instant'),messages=[{'role':'user','content':prompt}],temperature=0).choices[0].message.content
        try:
            import json; return Answer.model_validate_json(raw)
        except ValidationError:
            corrective='Return ONLY valid JSON matching the schema: {"answer": string, "sources": [string], "confidence": number between 0 and 1}.'
    return Answer(answer='ERROR: model output failed schema validation after three attempts.',sources=[],confidence=0.0)

def route(state: State): return 'retrieve_and_answer' if state['intent']=='policy_question' else 'direct_answer'

g=StateGraph(State); g.add_node('classify_intent',classify_intent); g.add_node('retrieve_and_answer',retrieve_and_answer); g.add_node('direct_answer',direct_answer); g.set_entry_point('classify_intent'); g.add_conditional_edges('classify_intent',route,{'retrieve_and_answer':'retrieve_and_answer','direct_answer':'direct_answer'}); g.add_edge('retrieve_and_answer',END); g.add_edge('direct_answer',END); GRAPH=g.compile()

def ask(query:str)->Answer: return GRAPH.invoke({'query':query})['response']

from fastapi import FastAPI
app=FastAPI(title='Zepto Support Assistant')
@app.post('/ask',response_model=Answer)
def ask_endpoint(req:AskRequest): return ask(req.query)

if __name__=='__main__':
    print(ask('What is the delivery fee below INR 149?').model_dump_json())
    print(ask('What is the capital of France?').model_dump_json())
